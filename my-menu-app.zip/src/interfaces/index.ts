export interface IProduct {
    id: number;
    src: string;
    alt: string;
    title: string;
    price: number;
    category: string
}